<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog/_entry_kategori_list */
class __TwigTemplate_70058c360ee571686d66f50857dcd90d1faae0fc17e4ac5901d067f3be2476f8 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/base.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "blog/_entry_kategori_list");
        // line 1
        $this->parent = $this->loadTemplate("_layouts/base.twig", "blog/_entry_kategori_list", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "blog/_entry_kategori_list");
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 4
        echo "<div class=\"flex sm:flex-row flex-wrap sm:mt-10 \">
  <div class=\"w-full sm:w-3/4  sm:px-8 text-center\">
    <div class=\" uppercase  text-4xl font-bold\">
      <h1> Selamat  Datang Di Fakhri BlogTech  </h1>
    </div>
      <p> Menampilkan : ";
        // line 9
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 9, $this->source); })()), "title", []), "html", null, true);
        echo "</p> 
    <div class=\"md:flex content-start md:flex-wrap mt-5 mb-10 mx-10\">
      ";
        // line 11
        $context["category"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 11, $this->source); })()), "categories", []), "slug", [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 11, $this->source); })()), "slug", [])], "method");
        // line 12
        echo "      ";
        $context["entry"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 12, $this->source); })()), "entries", [], "method"), "section", [0 => "post"], "method"), "type", [0 => "post"], "method"), "relatedTo", [0 =>         // line 15
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 15, $this->source); })())], "method"), "limit", [0 => 4], "method");
        // line 17
        echo "      ";
        list($context["pageInfo"], $context["pageEntries"]) = \craft\helpers\Template::paginateCriteria((isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 17, $this->source); })()));
        // line 18
        echo "      ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pageEntries"]) || array_key_exists("pageEntries", $context) ? $context["pageEntries"] : (function () { throw new RuntimeError('Variable "pageEntries" does not exist.', 18, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 19
            echo "        ";
            $this->loadTemplate("_include/blog_list.twig", "blog/_entry_kategori_list", 19)->display($context);
            // line 20
            echo "      ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "    </div>
    ";
        // line 22
        $this->loadTemplate("_include/paginate.twig", "blog/_entry_kategori_list", 22)->display($context);
        // line 23
        echo "  </div>
  ";
        // line 24
        $this->loadTemplate("_include/sidebar.twig", "blog/_entry_kategori_list", 24)->display($context);
        // line 25
        echo "</div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "blog/_entry_kategori_list";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  126 => 0,  123 => 25,  121 => 24,  118 => 23,  116 => 22,  113 => 21,  99 => 20,  96 => 19,  78 => 18,  75 => 17,  73 => 15,  71 => 12,  69 => 11,  64 => 9,  57 => 4,  55 => 0,  51 => 3,  47 => 0,  44 => 1,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/base.twig\" %}

{% block content %}
<div class=\"flex sm:flex-row flex-wrap sm:mt-10 \">
  <div class=\"w-full sm:w-3/4  sm:px-8 text-center\">
    <div class=\" uppercase  text-4xl font-bold\">
      <h1> Selamat  Datang Di Fakhri BlogTech  </h1>
    </div>
      <p> Menampilkan : {{category.title}}</p> 
    <div class=\"md:flex content-start md:flex-wrap mt-5 mb-10 mx-10\">
      {% set category = craft.categories.slug(category.slug) %}
      {% set entry = craft.entries()
        .section('post')
        .type('post').
        relatedTo(category)
        .limit(4) %}
      {% paginate entry as pageInfo, pageEntries %}
      {% for item in pageEntries %}
        {% include \"_include/blog_list.twig\" %}
      {% endfor %}
    </div>
    {% include \"_include/paginate.twig\" %}
  </div>
  {% include \"_include/sidebar.twig\" %}
</div>
{% endblock %}
", "blog/_entry_kategori_list", "C:\\laragon\\www\\fakhri-craft\\templates\\blog\\_entry_kategori_list.twig");
    }
}
