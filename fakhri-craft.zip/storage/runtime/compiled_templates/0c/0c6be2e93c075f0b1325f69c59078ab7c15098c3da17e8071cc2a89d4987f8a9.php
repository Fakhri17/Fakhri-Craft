<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _include/paginate.twig */
class __TwigTemplate_876ba8711cd588a16500fe4584e2a1a0b6e5b43b15abf3cf57e9ce836741555b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_include/paginate.twig");
        // line 1
        echo "<div class=\"container mx-auto p-6\">
  <div class=\"flex sm:justify-center\">
    ";
        // line 3
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["pageInfo"]) || array_key_exists("pageInfo", $context) ? $context["pageInfo"] : (function () { throw new RuntimeError('Variable "pageInfo" does not exist.', 3, $this->source); })()), "prevUrl", [])) {
            // line 4
            echo "      <a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["pageInfo"]) || array_key_exists("pageInfo", $context) ? $context["pageInfo"] : (function () { throw new RuntimeError('Variable "pageInfo" does not exist.', 4, $this->source); })()), "prevUrl", []), "html", null, true);
            echo "\" class=\"border rounded-lg rounded-l bg-transparent hover:bg-blue-500 text-blue-700 hover:text-white p-3\">prev</a>
    ";
        }
        // line 6
        echo "
    ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["pageInfo"]) || array_key_exists("pageInfo", $context) ? $context["pageInfo"] : (function () { throw new RuntimeError('Variable "pageInfo" does not exist.', 7, $this->source); })()), "getPrevUrls", [0 => 2], "method"));
        foreach ($context['_seq'] as $context["page"] => $context["url"]) {
            // line 8
            echo "    <a href=\"";
            echo twig_escape_filter($this->env, $context["url"], "html", null, true);
            echo "\" class=\"p-3 border border-l-0 bg-transparent hover:bg-blue-500 text-blue-700 hover:text-white\">";
            echo twig_escape_filter($this->env, $context["page"], "html", null, true);
            echo "</a>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['page'], $context['url'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 10
        echo "
    ";
        // line 11
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["pageInfo"]) || array_key_exists("pageInfo", $context) ? $context["pageInfo"] : (function () { throw new RuntimeError('Variable "pageInfo" does not exist.', 11, $this->source); })()), "totalPages", []) >= 2)) {
            echo "<span class=\"p-3 border border-l-0 bg-transparent hover:bg-blue-500 text-blue-700 hover:text-white\">
      ";
            // line 12
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["pageInfo"]) || array_key_exists("pageInfo", $context) ? $context["pageInfo"] : (function () { throw new RuntimeError('Variable "pageInfo" does not exist.', 12, $this->source); })()), "currentPage", []), "html", null, true);
            echo "</span>
    ";
        }
        // line 14
        echo "
    ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["pageInfo"]) || array_key_exists("pageInfo", $context) ? $context["pageInfo"] : (function () { throw new RuntimeError('Variable "pageInfo" does not exist.', 15, $this->source); })()), "getNextUrls", [0 => 2], "method"));
        foreach ($context['_seq'] as $context["page"] => $context["url"]) {
            // line 16
            echo "    <a href=\"";
            echo twig_escape_filter($this->env, $context["url"], "html", null, true);
            echo "\" class=\"p-3 border border-l-0 bg-transparent hover:bg-blue-500 text-blue-700 hover:text-white\">";
            echo twig_escape_filter($this->env, $context["page"], "html", null, true);
            echo "</a>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['page'], $context['url'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "
    ";
        // line 19
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["pageInfo"]) || array_key_exists("pageInfo", $context) ? $context["pageInfo"] : (function () { throw new RuntimeError('Variable "pageInfo" does not exist.', 19, $this->source); })()), "nextUrl", [])) {
            // line 20
            echo "    <a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["pageInfo"]) || array_key_exists("pageInfo", $context) ? $context["pageInfo"] : (function () { throw new RuntimeError('Variable "pageInfo" does not exist.', 20, $this->source); })()), "nextUrl", []), "html", null, true);
            echo "\" class=\"p-3 rounded-lg rounded-r border border-l-0 bg-transparent hover:bg-blue-500 text-blue-700 hover:text-white p-3\">next</a>
    ";
        }
        // line 22
        echo "  </div>
</div>";
        // line 0
        craft\helpers\Template::endProfile("template", "_include/paginate.twig");
    }

    public function getTemplateName()
    {
        return "_include/paginate.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 0,  109 => 22,  103 => 20,  101 => 19,  98 => 18,  87 => 16,  83 => 15,  80 => 14,  75 => 12,  71 => 11,  68 => 10,  57 => 8,  53 => 7,  50 => 6,  44 => 4,  42 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"container mx-auto p-6\">
  <div class=\"flex sm:justify-center\">
    {% if pageInfo.prevUrl %}
      <a href=\"{{ pageInfo.prevUrl }}\" class=\"border rounded-lg rounded-l bg-transparent hover:bg-blue-500 text-blue-700 hover:text-white p-3\">prev</a>
    {% endif %}

    {% for page, url in pageInfo.getPrevUrls(2) %}
    <a href=\"{{url}}\" class=\"p-3 border border-l-0 bg-transparent hover:bg-blue-500 text-blue-700 hover:text-white\">{{page}}</a>
    {% endfor %}

    {% if pageInfo.totalPages >= 2 %}<span class=\"p-3 border border-l-0 bg-transparent hover:bg-blue-500 text-blue-700 hover:text-white\">
      {{ pageInfo.currentPage }}</span>
    {% endif %}

    {% for page, url in pageInfo.getNextUrls(2) %}
    <a href=\"{{url}}\" class=\"p-3 border border-l-0 bg-transparent hover:bg-blue-500 text-blue-700 hover:text-white\">{{page}}</a>
    {% endfor %}

    {% if pageInfo.nextUrl %}
    <a href=\"{{ pageInfo.nextUrl }}\" class=\"p-3 rounded-lg rounded-r border border-l-0 bg-transparent hover:bg-blue-500 text-blue-700 hover:text-white p-3\">next</a>
    {% endif %}
  </div>
</div>", "_include/paginate.twig", "C:\\laragon\\www\\fakhri-craft\\templates\\_include\\paginate.twig");
    }
}
