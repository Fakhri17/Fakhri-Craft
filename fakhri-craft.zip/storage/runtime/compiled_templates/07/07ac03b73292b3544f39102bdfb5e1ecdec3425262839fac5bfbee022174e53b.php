<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* patrol/_settings */
class __TwigTemplate_b97fe171795378a6dae3f148fe08e43dfd829618f9fb823ea417ad813a99514b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "patrol/_settings");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "patrol/_settings", 1)->unwrap();
        // line 2
        echo "
<script type=\"text/javascript\">
\t";
        // line 5
        echo "\tvar \$settings = JSON.parse('";
        echo (isset($context["settingsJson"]) || array_key_exists("settingsJson", $context) ? $context["settingsJson"] : (function () { throw new RuntimeError('Variable "settingsJson" does not exist.', 5, $this->source); })());
        echo "');
</script>

<div class=\"patrol\">
\t<h2>";
        // line 9
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["plugin"]) || array_key_exists("plugin", $context) ? $context["plugin"] : (function () { throw new RuntimeError('Variable "plugin" does not exist.', 9, $this->source); })()), "name", []), "html", null, true);
        echo "&nbsp;<span class=\"subtle\">V";
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["plugin"]) || array_key_exists("plugin", $context) ? $context["plugin"] : (function () { throw new RuntimeError('Variable "plugin" does not exist.', 9, $this->source); })()), "version", []), "html", null, true);
        echo "</span></h2>
\t<p>
\t\t";
        // line 11
        echo $this->extensions['craft\web\twig\Extension']->markdownFilter($this->extensions['craft\web\twig\Extension']->translateFilter("Simplifies **SSL Routing** and **Maintenance Mode**", "patrol"));
        echo "
\t</p>
\t<div class=\"section\">
\t\t<h3 class=\"maintenance\">";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Maintenance Mode", "patrol"), "html", null, true);
        echo "</h3>
\t\t<p class=\"subtle\">";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Enable maintenance mode and use the rules defined below", "patrol"), "html", null, true);
        echo "</p>
\t\t";
        // line 16
        echo twig_call_macro($macros["forms"], "macro_lightswitch", [["onLabel" => "On", "offLabel" => "Off", "name" => "maintenanceModeEnabled", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 20
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 20, $this->source); })()), "maintenanceModeEnabled", []), "errors" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 21
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 21, $this->source); })()), "hasErrors", [0 => "maintenanceModeEnabled"], "method")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 21, $this->source); })()), "getError", [0 => "maintenanceModeEnabled"], "method")) : (""))]], 16, $context, $this->getSourceContext());
        // line 23
        echo "
\t\t";
        // line 24
        echo twig_call_macro($macros["forms"], "macro_textField", [["id" => "maintenanceModePageUrl", "name" => "maintenanceModePageUrl", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Maintenance Mode Page URL", "patrol"), "class" => "code", "placeholder" => "/maintenance", "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The URL to redirect unauthorized traffic to if maintenance mode is enabled", "patrol"), "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 31
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 31, $this->source); })()), "maintenanceModePageUrl", []), "errors" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 32
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 32, $this->source); })()), "hasErrors", [0 => "maintenanceModePageUrl"], "method")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 32, $this->source); })()), "getError", [0 => "maintenanceModePageUrl"], "method")) : (""))]], 24, $context, $this->getSourceContext());
        // line 33
        echo "

\t\t<div class=\"field\">
\t\t\t<div class=\"heading\">
\t\t\t\t<label>";
        // line 37
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Authorized IPs", "patrol"), "html", null, true);
        echo "</label>
\t\t\t\t<div class=\"instructions\">
\t\t\t\t\t<p>";
        // line 39
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("The IP addresses that should be able to access the site while on maintenance mode", "patrol"), "html", null, true);
        echo "</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<input type=\"hidden\" name=\"maintenanceModeAuthorizedIps[]\">
\t\t\t<div class=\"input\" v-repeat=\"ip: maintenanceModeAuthorizedIps\">
\t\t\t\t<input class=\"text nicetext code\" type=\"text\" v-model=\"ip\" name=\"maintenanceModeAuthorizedIps[]\">
\t\t\t\t<button type=\"button\" class=\"btn icon delete\" v-on=\"click: removeIp(ip)\"></button>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"field\">
\t\t\t<input type=\"text\" class=\"text nicetext code\" v-model=\"newIp\" placeholder=\"127.0.0.1\">
\t\t\t<button type=\"button\" class=\"btn icon add\" v-on=\"click: addIp\"></button>
\t\t</div>
\t</div>

\t<div class=\"section\">
\t\t<h3 class=\"security\">";
        // line 55
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("SSL Routing", "patrol"), "html", null, true);
        echo "</h3>
\t\t<p class=\"subtle\">";
        // line 56
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Enable SSL routing and force HTTPS using the rules defined below", "patrol"), "html", null, true);
        echo "</p>
\t\t";
        // line 57
        echo twig_call_macro($macros["forms"], "macro_lightswitch", [["onLabel" => "On", "offLabel" => "Off", "name" => "sslRoutingEnabled", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 61
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 61, $this->source); })()), "sslRoutingEnabled", []), "disabled" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 62
($context["configs"] ?? null), "sslRoutingEnabled", [], "any", true, true)) ? (true) : (false))]], 57, $context, $this->getSourceContext());
        // line 63
        echo "

\t\t<div class=\"field\">
\t\t\t<div class=\"heading\">
\t\t\t\t<label>";
        // line 67
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Restricted URL Segments", "patrol"), "html", null, true);
        echo "</label>
\t\t\t\t<div class=\"instructions\">
\t\t\t\t\t<p>";
        // line 69
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("The URL segments where HTTPS should be enforced", "patrol"), "html", null, true);
        echo "</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<input type=\"hidden\" name=\"sslRoutingRestrictedUrls[]\">
\t\t\t<div class=\"input\" v-repeat=\"url: sslRoutingRestrictedUrls\">
\t\t\t\t<input class=\"text nicetext\" type=\"text\" v-model=\"url\" name=\"sslRoutingRestrictedUrls[]\">
\t\t\t\t<button type=\"button\" class=\"btn icon delete\" v-on=\"click: removeUrl(url)\"></button>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"field\">
\t\t\t<input type=\"text\" class=\"text nicetext\" v-model=\"newUrl\" placeholder=\"/members\">
\t\t\t<button type=\"button\" class=\"btn icon add\" v-on=\"click: addUrl\"></button>
\t\t</div>
\t</div>

\t<div class=\"section credits\">
\t\t<p>
\t\t\t&copy; ";
        // line 86
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, "now", "Y"), "html", null, true);
        echo "
\t\t\t<strong>";
        // line 87
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Patrol", "patrol"), "html", null, true);
        echo " <span class=\"subtle\">(";
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["plugin"]) || array_key_exists("plugin", $context) ? $context["plugin"] : (function () { throw new RuntimeError('Variable "plugin" does not exist.', 87, $this->source); })()), "version", []), "html", null, true);
        echo ")</span></strong>
\t\t\t<em>by</em>
\t\t\t<a href=\"https://selvinortiz.com\" title=\"Selvin Ortiz\" target=\"_blank\">Selvin Ortiz</a>
\t\t</p>
\t</div>
</div>
";
        // line 0
        craft\helpers\Template::endProfile("template", "patrol/_settings");
    }

    public function getTemplateName()
    {
        return "patrol/_settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  172 => 0,  161 => 87,  157 => 86,  137 => 69,  132 => 67,  126 => 63,  124 => 62,  123 => 61,  122 => 57,  118 => 56,  114 => 55,  95 => 39,  90 => 37,  84 => 33,  82 => 32,  81 => 31,  80 => 24,  77 => 23,  75 => 21,  74 => 20,  73 => 16,  69 => 15,  65 => 14,  59 => 11,  52 => 9,  44 => 5,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}

<script type=\"text/javascript\">
\t{# \$settings is consumed by VueJS #}
\tvar \$settings = JSON.parse('{{ settingsJson|raw }}');
</script>

<div class=\"patrol\">
\t<h2>{{ plugin.name }}&nbsp;<span class=\"subtle\">V{{ plugin.version }}</span></h2>
\t<p>
\t\t{{ 'Simplifies **SSL Routing** and **Maintenance Mode**'|t('patrol')|md }}
\t</p>
\t<div class=\"section\">
\t\t<h3 class=\"maintenance\">{{ 'Maintenance Mode'|t('patrol') }}</h3>
\t\t<p class=\"subtle\">{{ 'Enable maintenance mode and use the rules defined below'|t('patrol') }}</p>
\t\t{{ forms.lightswitch({
\t\t\tonLabel:    \"On\",
\t\t\toffLabel:    \"Off\",
\t\t\tname:        \"maintenanceModeEnabled\",
\t\t\ton:            settings.maintenanceModeEnabled,
\t\t\terrors:        settings.hasErrors('maintenanceModeEnabled') ? settings.getError('maintenanceModeEnabled')

\t\t}) }}
\t\t{{ forms.textField({
\t\t\tid:                \"maintenanceModePageUrl\",
\t\t\tname:            \"maintenanceModePageUrl\",
\t\t\tlabel:            \"Maintenance Mode Page URL\"|t('patrol'),
\t\t\tclass:            \"code\",
\t\t\tplaceholder:    \"/maintenance\",
\t\t\tinstructions:    \"The URL to redirect unauthorized traffic to if maintenance mode is enabled\"|t('patrol'),
\t\t\tvalue:            settings.maintenanceModePageUrl,
\t\t\terrors:            settings.hasErrors('maintenanceModePageUrl') ? settings.getError('maintenanceModePageUrl')
\t\t}) }}

\t\t<div class=\"field\">
\t\t\t<div class=\"heading\">
\t\t\t\t<label>{{ 'Authorized IPs'|t('patrol') }}</label>
\t\t\t\t<div class=\"instructions\">
\t\t\t\t\t<p>{{ 'The IP addresses that should be able to access the site while on maintenance mode'|t('patrol') }}</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<input type=\"hidden\" name=\"maintenanceModeAuthorizedIps[]\">
\t\t\t<div class=\"input\" v-repeat=\"ip: maintenanceModeAuthorizedIps\">
\t\t\t\t<input class=\"text nicetext code\" type=\"text\" v-model=\"ip\" name=\"maintenanceModeAuthorizedIps[]\">
\t\t\t\t<button type=\"button\" class=\"btn icon delete\" v-on=\"click: removeIp(ip)\"></button>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"field\">
\t\t\t<input type=\"text\" class=\"text nicetext code\" v-model=\"newIp\" placeholder=\"127.0.0.1\">
\t\t\t<button type=\"button\" class=\"btn icon add\" v-on=\"click: addIp\"></button>
\t\t</div>
\t</div>

\t<div class=\"section\">
\t\t<h3 class=\"security\">{{ 'SSL Routing'|t('patrol') }}</h3>
\t\t<p class=\"subtle\">{{ 'Enable SSL routing and force HTTPS using the rules defined below'|t('patrol') }}</p>
\t\t{{ forms.lightswitch({
\t\t\tonLabel:    \"On\",
\t\t\toffLabel:    \"Off\",
\t\t\tname:        \"sslRoutingEnabled\",
\t\t\ton:            settings.sslRoutingEnabled,
\t\t\tdisabled:    configs.sslRoutingEnabled is defined ? true : false
\t\t}) }}

\t\t<div class=\"field\">
\t\t\t<div class=\"heading\">
\t\t\t\t<label>{{ 'Restricted URL Segments'|t('patrol') }}</label>
\t\t\t\t<div class=\"instructions\">
\t\t\t\t\t<p>{{ 'The URL segments where HTTPS should be enforced'|t('patrol') }}</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<input type=\"hidden\" name=\"sslRoutingRestrictedUrls[]\">
\t\t\t<div class=\"input\" v-repeat=\"url: sslRoutingRestrictedUrls\">
\t\t\t\t<input class=\"text nicetext\" type=\"text\" v-model=\"url\" name=\"sslRoutingRestrictedUrls[]\">
\t\t\t\t<button type=\"button\" class=\"btn icon delete\" v-on=\"click: removeUrl(url)\"></button>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"field\">
\t\t\t<input type=\"text\" class=\"text nicetext\" v-model=\"newUrl\" placeholder=\"/members\">
\t\t\t<button type=\"button\" class=\"btn icon add\" v-on=\"click: addUrl\"></button>
\t\t</div>
\t</div>

\t<div class=\"section credits\">
\t\t<p>
\t\t\t&copy; {{ \"now\" | date(\"Y\") }}
\t\t\t<strong>{{ 'Patrol'|t('patrol') }} <span class=\"subtle\">({{ plugin.version }})</span></strong>
\t\t\t<em>by</em>
\t\t\t<a href=\"https://selvinortiz.com\" title=\"Selvin Ortiz\" target=\"_blank\">Selvin Ortiz</a>
\t\t</p>
\t</div>
</div>
", "patrol/_settings", "C:\\laragon\\www\\fakhri-craft\\vendor\\selvinortiz\\patrol\\src\\templates\\_settings.html");
    }
}
