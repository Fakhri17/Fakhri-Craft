<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _include/sidebar.twig */
class __TwigTemplate_09d77f1f3b165d141c692568146265840f83d75c29d4e8e9da4c1940a880f1c4 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_include/sidebar.twig");
        // line 1
        echo "<div class=\"w-full sm:w-1/4  sm:pt-1  \">
  <h1 class=\"text-center uppercase  text-4xl font-bold\">Post Terbaru</h1>
  <div class=\"bg-gray-700 h-1 sm:mt-4 sm:mx-5\"></div>
  <ul class=\"list-inside p-5\">
    ";
        // line 5
        $context["post"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "entries", [], "method"), "section", [0 => "post"], "method"), "type", [0 => "post"], "method"), "limit", [0 => 3], "method");
        // line 10
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["post"]) || array_key_exists("post", $context) ? $context["post"] : (function () { throw new RuntimeError('Variable "post" does not exist.', 10, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 11
            echo "      <li class=\"pb-2\"><a class=\"hover:text-blue-600 hover:underline\"href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "url", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "title", []), "html", null, true);
            echo " 
      </a><p class=\"text-sm text-gray-600\">( ";
            // line 12
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "postDate", []), "d F Y g:i A"), "html", null, true);
            echo " )</p></li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "  </ul>
  <h1 class=\"text-center uppercase  text-4xl font-bold\">Kategori</h1>
  <div class=\"bg-gray-700 h-1 sm:mt-4 sm:mx-5\"></div>
  <ul class=\"list-inside p-5\">
    ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 18, $this->source); })()), "categories", []), "all", [], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 19
            echo "      <li class=\"pb-2\"><a class=\"hover:text-blue-600 hover:underline\"href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "url", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "title", []), "html", null, true);
            echo "</a>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "  </ul>
</div>
<!-- <a href=\"#\" id=\"scroll\" style=\"display: none;\"><span></span></a> -->";
        // line 0
        craft\helpers\Template::endProfile("template", "_include/sidebar.twig");
    }

    public function getTemplateName()
    {
        return "_include/sidebar.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 0,  87 => 21,  76 => 19,  72 => 18,  66 => 14,  58 => 12,  51 => 11,  46 => 10,  44 => 5,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"w-full sm:w-1/4  sm:pt-1  \">
  <h1 class=\"text-center uppercase  text-4xl font-bold\">Post Terbaru</h1>
  <div class=\"bg-gray-700 h-1 sm:mt-4 sm:mx-5\"></div>
  <ul class=\"list-inside p-5\">
    {% set post =  craft.entries()
      .section('post')
      .type('post')
      .limit(3) 
    %}
    {% for item in post %}
      <li class=\"pb-2\"><a class=\"hover:text-blue-600 hover:underline\"href=\"{{item.url}}\">{{item.title}} 
      </a><p class=\"text-sm text-gray-600\">( {{item.postDate|date(\"d F Y g:i A\")}} )</p></li>
    {% endfor %}
  </ul>
  <h1 class=\"text-center uppercase  text-4xl font-bold\">Kategori</h1>
  <div class=\"bg-gray-700 h-1 sm:mt-4 sm:mx-5\"></div>
  <ul class=\"list-inside p-5\">
    {% for item in craft.categories.all() %}
      <li class=\"pb-2\"><a class=\"hover:text-blue-600 hover:underline\"href=\"{{item.url}}\">{{item.title}}</a>
    {% endfor %}
  </ul>
</div>
<!-- <a href=\"#\" id=\"scroll\" style=\"display: none;\"><span></span></a> -->", "_include/sidebar.twig", "C:\\laragon\\www\\fakhri-craft\\templates\\_include\\sidebar.twig");
    }
}
