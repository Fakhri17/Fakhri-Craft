<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _special/configsync */
class __TwigTemplate_01f04f1be8d8f5fb65a5dc60333c266590b1ff420734a4b6aa5cd23c091b3b44 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'message' => [$this, 'block_message'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/message";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "_special/configsync");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Project Config Sync", "app");
        // line 1
        $this->parent = $this->loadTemplate("_layouts/message", "_special/configsync", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "_special/configsync");
    }

    // line 4
    public function block_message($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "message");
        // line 5
        echo "    <p>";
        echo $this->extensions['craft\web\twig\Extension']->markdownFilter($this->extensions['craft\web\twig\Extension']->translateFilter("Changes to `project.yaml` must be applied to the loaded project config.", "app"), null, true);
        echo "</p>

    <form method=\"post\" class=\"buttons\">
        ";
        // line 8
        echo craft\helpers\Html::csrfInput();
        echo "
        ";
        // line 9
        echo craft\helpers\Html::actionInput("config-sync");
        echo "
        ";
        // line 10
        echo craft\helpers\Html::hiddenInput("return", craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 10, $this->source); })()), "app", []), "request", []), "getPathInfo", [], "method"));
        echo "
        <input type=\"submit\" class=\"btn submit\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sync changes", "app"), "html", null, true);
        echo "\">
    </form>
";
        // line 0
        craft\helpers\Template::endProfile("block", "message");
    }

    public function getTemplateName()
    {
        return "_special/configsync";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  83 => 0,  78 => 11,  74 => 10,  70 => 9,  66 => 8,  59 => 5,  57 => 0,  53 => 4,  49 => 0,  46 => 1,  44 => 2,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/message\" %}
{% set title = \"Project Config Sync\"|t('app') %}

{% block message %}
    <p>{{ \"Changes to `project.yaml` must be applied to the loaded project config.\"|t('app')|md(inlineOnly=true) }}</p>

    <form method=\"post\" class=\"buttons\">
        {{ csrfInput() }}
        {{ actionInput('config-sync') }}
        {{ hiddenInput('return', craft.app.request.getPathInfo()) }}
        <input type=\"submit\" class=\"btn submit\" value=\"{{ 'Sync changes'|t('app') }}\">
    </form>
{% endblock %}
", "_special/configsync", "C:\\laragon\\www\\fakhri-craft\\vendor\\craftcms\\cms\\src\\templates\\_special\\configsync.html");
    }
}
