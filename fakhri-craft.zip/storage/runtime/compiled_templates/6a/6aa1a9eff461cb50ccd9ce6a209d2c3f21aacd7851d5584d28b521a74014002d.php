<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _include/header.twig */
class __TwigTemplate_9c18e2a47badee214998bc8eeab41401127187ae79b3098f2279f16c12432621 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_include/header.twig");
        // line 1
        echo "<nav class=\"nav flex flex-wrap items-center justify-between px-5 bg-blue-400 sticky top-0 sm:shadow-lg z-20 md:z-20\" >
  <div class=\"flex flex-no-shrink items-center mr-6 py-5 text-grey-darkest \">
    <span class=\"font-semibold text-xl tracking-tight\"><a href=\"";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 3, $this->source); })()), "html", null, true);
        echo "\">Fakhri Alauddin</a></span>
  </div>

  <input class=\"menu-btn hidden\" type=\"checkbox\" id=\"menu-btn\">
  <label class=\"menu-icon block cursor-pointer md:hidden px-2 py-4 relative select-none\" for=\"menu-btn\">
    <span class=\"navicon bg-grey-darkest flex items-center relative\"></span>
  </label>

  <ul class=\"menu border-b md:border-none flex justify-end list-reset m-0 w-full md:w-auto\">
    <li class=\"border-t md:border-none hover:bg-blue-300\">
      <a href=\"";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 13, $this->source); })()), "html", null, true);
        echo "\" class=\"block md:inline-block px-5 py-3 no-underline text-grey-darkest hover:text-grey-darker text-xl \">Home</a>
    </li>
    <li class=\"border-t md:border-none hover:bg-blue-300\">
      <a href=\"";
        // line 16
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 16, $this->source); })()), "html", null, true);
        echo "about\" class=\"block md:inline-block px-5 py-3 no-underline text-grey-darkest hover:text-grey-darker text-xl\">About</a>
    </li>
  </ul>
</nav>";
        // line 0
        craft\helpers\Template::endProfile("template", "_include/header.twig");
    }

    public function getTemplateName()
    {
        return "_include/header.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 0,  61 => 16,  55 => 13,  42 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<nav class=\"nav flex flex-wrap items-center justify-between px-5 bg-blue-400 sticky top-0 sm:shadow-lg z-20 md:z-20\" >
  <div class=\"flex flex-no-shrink items-center mr-6 py-5 text-grey-darkest \">
    <span class=\"font-semibold text-xl tracking-tight\"><a href=\"{{siteUrl}}\">Fakhri Alauddin</a></span>
  </div>

  <input class=\"menu-btn hidden\" type=\"checkbox\" id=\"menu-btn\">
  <label class=\"menu-icon block cursor-pointer md:hidden px-2 py-4 relative select-none\" for=\"menu-btn\">
    <span class=\"navicon bg-grey-darkest flex items-center relative\"></span>
  </label>

  <ul class=\"menu border-b md:border-none flex justify-end list-reset m-0 w-full md:w-auto\">
    <li class=\"border-t md:border-none hover:bg-blue-300\">
      <a href=\"{{siteUrl}}\" class=\"block md:inline-block px-5 py-3 no-underline text-grey-darkest hover:text-grey-darker text-xl \">Home</a>
    </li>
    <li class=\"border-t md:border-none hover:bg-blue-300\">
      <a href=\"{{siteUrl}}about\" class=\"block md:inline-block px-5 py-3 no-underline text-grey-darkest hover:text-grey-darker text-xl\">About</a>
    </li>
  </ul>
</nav>", "_include/header.twig", "C:\\laragon\\www\\fakhri-craft\\templates\\_include\\header.twig");
    }
}
