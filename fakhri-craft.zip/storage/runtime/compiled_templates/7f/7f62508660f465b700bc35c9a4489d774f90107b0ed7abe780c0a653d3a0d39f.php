<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/*  */
class __TwigTemplate_86ce1bc5c9e570e2c8ee210a4e3c63b34d215f7cb04751718e9df30cdfdc2c20 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/base.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "");
        // line 1
        $this->parent = $this->loadTemplate("_layouts/base.twig", "", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "");
    }

    // line 2
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 3
        echo "<div class=\"flex sm:flex-row flex-wrap sm:mt-10 \">
  <div class=\"w-full sm:w-3/4  sm:px-8 text-center\"> 
    <div class=\" uppercase  text-4xl font-bold\" >
      <h1> Selamat  Datang Di Fakhri BlogTech </h1> 
    </div>
  ";
        // line 8
        $context["entry"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 8, $this->source); })()), "entries", [], "method"), "section", [0 => "post"], "method"), "type", [0 => "post"], "method"), "limit", [0 => 4], "method");
        // line 12
        echo "    <div class=\"sm:flex content-start sm:flex-wrap mt-5 mb-10 mx-10\">     
      ";
        // line 13
        list($context["pageInfo"], $context["pageEntries"]) = \craft\helpers\Template::paginateCriteria((isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 13, $this->source); })()));
        // line 14
        echo "      ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pageEntries"]) || array_key_exists("pageEntries", $context) ? $context["pageEntries"] : (function () { throw new RuntimeError('Variable "pageEntries" does not exist.', 14, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 15
            echo "        ";
            $this->loadTemplate("_include/blog_list.twig", "", 15)->display($context);
            // line 16
            echo "      ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "    </div>
    ";
        // line 18
        $this->loadTemplate("_include/paginate.twig", "", 18)->display($context);
        // line 19
        echo "  </div>
  ";
        // line 20
        $this->loadTemplate("_include/sidebar.twig", "", 20)->display($context);
        // line 21
        echo "</div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 0,  116 => 21,  114 => 20,  111 => 19,  109 => 18,  106 => 17,  92 => 16,  89 => 15,  71 => 14,  69 => 13,  66 => 12,  64 => 8,  57 => 3,  55 => 0,  51 => 2,  47 => 0,  44 => 1,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/base.twig\" %}
{% block content %}
<div class=\"flex sm:flex-row flex-wrap sm:mt-10 \">
  <div class=\"w-full sm:w-3/4  sm:px-8 text-center\"> 
    <div class=\" uppercase  text-4xl font-bold\" >
      <h1> Selamat  Datang Di Fakhri BlogTech </h1> 
    </div>
  {% set entry =  craft.entries()
    .section('post')
    .type('post')
    .limit(4) %}
    <div class=\"sm:flex content-start sm:flex-wrap mt-5 mb-10 mx-10\">     
      {% paginate entry as pageInfo, pageEntries %}
      {% for item in pageEntries %}
        {% include \"_include/blog_list.twig\" %}
      {% endfor %}
    </div>
    {% include \"_include/paginate.twig\" %}
  </div>
  {% include \"_include/sidebar.twig\" %}
</div>
{% endblock  %}", "", "C:\\laragon\\www\\fakhri-craft\\templates\\index.twig");
    }
}
