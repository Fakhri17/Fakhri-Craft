<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/message */
class __TwigTemplate_04773d0452b3ed1305302d2514e4f4f53a39856c29c1a84911189df0847d344b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'message' => [$this, 'block_message'],
            'foot' => [$this, 'block_foot'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/base";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "_layouts/message");
        // line 2
        $context["bodyClass"] = "message";
        // line 1
        $this->parent = $this->loadTemplate("_layouts/base", "_layouts/message", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "_layouts/message");
    }

    // line 4
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "body");
        // line 5
        echo "    <div class=\"message-container\">
        <div id=\"message\" class=\"pane\">
            ";
        // line 7
        $this->displayBlock('message', $context, $blocks);
        // line 8
        echo "        </div>
    </div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "body");
    }

    // line 7
    public function block_message($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "message");
        craft\helpers\Template::endProfile("block", "message");
    }

    // line 12
    public function block_foot($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "foot");
        // line 13
        echo "    <script type=\"text/javascript\">
        var message = document.getElementById('message'),
            margin = -Math.round(message.offsetHeight / 2);
        message.setAttribute('style', 'margin-top: '+margin+'px !important;');
    </script>
";
        // line 0
        craft\helpers\Template::endProfile("block", "foot");
    }

    public function getTemplateName()
    {
        return "_layouts/message";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 0,  90 => 13,  88 => 0,  84 => 12,  79 => 0,  75 => 7,  71 => 0,  67 => 8,  65 => 7,  61 => 5,  59 => 0,  55 => 4,  51 => 0,  48 => 1,  46 => 2,  44 => 0,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/base\" %}
{% set bodyClass = 'message' %}

{% block body %}
    <div class=\"message-container\">
        <div id=\"message\" class=\"pane\">
            {% block message %}{% endblock %}
        </div>
    </div>
{% endblock %}

{% block foot %}
    <script type=\"text/javascript\">
        var message = document.getElementById('message'),
            margin = -Math.round(message.offsetHeight / 2);
        message.setAttribute('style', 'margin-top: '+margin+'px !important;');
    </script>
{% endblock %}
", "_layouts/message", "C:\\laragon\\www\\fakhri-craft\\vendor\\craftcms\\cms\\src\\templates\\_layouts\\message.html");
    }
}
