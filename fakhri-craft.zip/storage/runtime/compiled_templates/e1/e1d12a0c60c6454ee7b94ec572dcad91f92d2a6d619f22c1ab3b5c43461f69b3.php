<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* plugin-store/_index */
class __TwigTemplate_e9206462e315eef388063792a868e6f8b9510b72abbe2f6be252cadee1f958ea extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "plugin-store/_index");
        // line 3
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Plugin Store", "app");
        // line 5
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 5, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Active installs", 1 => "Active Trials", 2 => "Add all to cart", 3 => "Add to cart", 4 => "Added to cart", 5 => "Address Line 1", 6 => "Address Line 2", 7 => "Already in your cart", 8 => "Ascending", 9 => "Back", 10 => "Billing", 11 => "Business Name", 12 => "Business Tax ID", 13 => "Buy later", 14 => "Buy now for {price}", 15 => "Buy now", 16 => "Card number", 17 => "Cart", 18 => "Categories", 19 => "Changelog", 20 => "Checkout", 21 => "City", 22 => "Cloud Storage Integration", 23 => "Community Support (Slack, Stack Exchange)", 24 => "Compatibility", 25 => "Connect to your Craft ID", 26 => "Contact", 27 => "Content Modeling", 28 => "Continue as guest", 29 => "Continue", 30 => "Copy the package’s name for this plugin.", 31 => "Couldn’t load active trials.", 32 => "Coupon Code", 33 => "CVC", 34 => "Descending", 35 => "Description", 36 => "Developer Support", 37 => "Documentation", 38 => "Features", 39 => "First Name", 40 => "For when you’re building a website for yourself or a friend.", 41 => "For when you’re building something professionally for a client or team.", 42 => "Free", 43 => "Includes Custom login screen logo, Custom site icon, Custom HTML email template, Custom email message wording", 44 => "Includes Multiple locales, Section and entry locale targeting, Content translations", 45 => "Includes Sections, Global sets, Category groups, Tag groups, Asset volumes, Custom fields, Entry versioning, and Entry drafts", 46 => "Includes User accounts, User groups, User permissions, Public user registration", 47 => "Information", 48 => "Install", 49 => "Installed as a trial", 50 => "Installed", 51 => "Item", 52 => "Items in your cart", 53 => "Last Name", 54 => "Last update", 55 => "Last Update", 56 => "Less", 57 => "License", 58 => "Licensed", 59 => "Loading Plugin Store…", 60 => "Manage plugins", 61 => "MM / YY", 62 => "More", 63 => "Multi-site Multi-lingual", 64 => "Name", 65 => "Only up to {version} is compatible with your version of Craft.", 66 => "Package Name", 67 => "Page not found.", 68 => "Pay", 69 => "Payment Method", 70 => "Payment", 71 => "Plugin Name", 72 => "Plugin Store", 73 => "Popularity", 74 => "Price includes 1 year of updates.", 75 => "Pro Rate Discount", 76 => "Reactivate", 77 => "Remove", 78 => "Renewal price", 79 => "Report an issue", 80 => "Save as my new credit card", 81 => "Screenshots", 82 => "Search plugins", 83 => "Security & Bug Fixes", 84 => "See all", 85 => "Showing results for “{searchQuery}”", 86 => "Staff Picks", 87 => "Subtotal", 88 => "Support", 89 => "System Branding", 90 => "Thank You!", 91 => "The Plugin Store is not available, please try again later.", 92 => "This plugin isn’t compatible with your version of Craft.", 93 => "Total Price", 94 => "Total", 95 => "Try for free", 96 => "Try", 97 => "Try", 98 => "Updates until {date} ({sign}{price})", 99 => "Updates until {date}", 100 => "Updates", 101 => "Upgrade Craft CMS", 102 => "Use a new credit card", 103 => "Use card {cardDetails}", 104 => "Use your Craft ID", 105 => "User Accounts", 106 => "Version {version}", 107 => "Version", 108 => "Website", 109 => "Your order has been processed successfully.", 110 => "Zip Code", 111 => "{price} plus {renewalPrice}/year for updates", 112 => "{price}/year", 113 => "{renewalPrice}/year per site for updates after that.", 114 => "Your are currently using the {currentEdition} edition, and your licensed edition is {licensedEdition}.", 115 => "This license is tied to another Craft install. Purchase a license for this install.", 116 => "Your license key is invalid.", 117 => "Critical", 118 => "Couldn’t add all items to the cart.", 119 => "No results."]], "method");
        // line 161
        $context["content"] = ('' === $tmp = "    <div id=\"app\"></div>
") ? '' : new Markup($tmp, $this->env->getCharset());
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "plugin-store/_index", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "plugin-store/_index");
    }

    // line 128
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 129
        echo "    <div id=\"pluginstore-actions-spinner\" class=\"spinner lg hidden\"></div>

    <div id=\"pluginstore-actions\" class=\"hidden\">

        <a id=\"cart-button\" role=\"button\" tabindex=\"0\">";
        // line 133
        echo $this->extensions['craft\web\twig\Extension']->svgFunction("@app/icons/shopping-cart.svg", null, true);
        echo " <span class=\"badge\">0</span></a>

        <a id=\"craftid-account\" class=\"menubtn hidden\"><span class=\"photo\">";
        // line 135
        echo $this->extensions['craft\web\twig\Extension']->svgFunction("@app/icons/craftid.svg", null, true);
        echo "</span><span class=\"label\">Account</span></a>

        <div class=\"menu\">
            <ul>
                <li><a href=\"";
        // line 139
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 139, $this->source); })()), "cp", []), "craftIdAccountUrl", [], "method"), "html", null, true);
        echo "\" rel=\"noopener\" target=\"_blank\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Manage your Craft ID", "app"), "html", null, true);
        echo "</a></li>
                <li>
                    <form method=\"post\" id=\"disconnect\">
                        ";
        // line 142
        echo craft\helpers\Html::csrfInput();
        echo "
                        ";
        // line 143
        echo craft\helpers\Html::actionInput("plugin-store/disconnect");
        echo "
                        <a onclick=\"document.getElementById('disconnect').submit();\">";
        // line 144
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sign out from Craft ID", "app"), "html", null, true);
        echo "</a>
                    </form>
                </li>
            </ul>
        </div>

        <form id=\"craftid-connect-form\" method=\"post\">
            ";
        // line 151
        echo craft\helpers\Html::csrfInput();
        echo "
            ";
        // line 152
        echo craft\helpers\Html::actionInput("plugin-store/connect");
        echo "
            <div class=\"ssl-status light\" title=\"";
        // line 153
        echo twig_escape_filter($this->env, ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 153, $this->source); })()), "app", []), "request", []), "isSecureConnection", [])) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Your connection is secure", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Your connection is insecure", "app"))), "html", null, true);
        echo "\">
                <i class=\"";
        // line 154
        echo ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 154, $this->source); })()), "app", []), "request", []), "isSecureConnection", [])) ? ("secure") : ("insecure"));
        echo " icon\"></i>
            </div>
            <a onclick=\"document.getElementById('craftid-connect-form').submit();\">";
        // line 156
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sign into Craft ID", "app"), "html", null, true);
        echo "</a>
        </form>
    </div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    public function getTemplateName()
    {
        return "plugin-store/_index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  131 => 0,  125 => 156,  120 => 154,  116 => 153,  112 => 152,  108 => 151,  98 => 144,  94 => 143,  90 => 142,  82 => 139,  75 => 135,  70 => 133,  64 => 129,  62 => 0,  58 => 128,  54 => 0,  51 => 1,  48 => 161,  46 => 5,  44 => 3,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% set title = 'Plugin Store'|t('app') %}

{% do view.registerTranslations('app', [
    \"Active installs\",
    \"Active Trials\",
    \"Add all to cart\",
    \"Add to cart\",
    \"Added to cart\",
    \"Address Line 1\",
    \"Address Line 2\",
    \"Already in your cart\",
    \"Ascending\",
    \"Back\",
    \"Billing\",
    \"Business Name\",
    \"Business Tax ID\",
    \"Buy later\",
    \"Buy now for {price}\",
    \"Buy now\",
    \"Card number\",
    \"Cart\",
    \"Categories\",
    \"Changelog\",
    \"Checkout\",
    \"City\",
    \"Cloud Storage Integration\",
    \"Community Support (Slack, Stack Exchange)\",
    \"Compatibility\",
    \"Connect to your Craft ID\",
    \"Contact\",
    \"Content Modeling\",
    \"Continue as guest\",
    \"Continue\",
    \"Copy the package’s name for this plugin.\",
    \"Couldn’t load active trials.\",
    \"Coupon Code\",
    \"CVC\",
    \"Descending\",
    \"Description\",
    \"Developer Support\",
    \"Documentation\",
    \"Features\",
    \"First Name\",
    \"For when you’re building a website for yourself or a friend.\",
    \"For when you’re building something professionally for a client or team.\",
    \"Free\",
    \"Includes Custom login screen logo, Custom site icon, Custom HTML email template, Custom email message wording\",
    \"Includes Multiple locales, Section and entry locale targeting, Content translations\",
    \"Includes Sections, Global sets, Category groups, Tag groups, Asset volumes, Custom fields, Entry versioning, and Entry drafts\",
    \"Includes User accounts, User groups, User permissions, Public user registration\",
    \"Information\",
    \"Install\",
    \"Installed as a trial\",
    \"Installed\",
    \"Item\",
    \"Items in your cart\",
    \"Last Name\",
    \"Last update\",
    \"Last Update\",
    \"Less\",
    \"License\",
    \"Licensed\",
    \"Loading Plugin Store…\",
    \"Manage plugins\",
    \"MM / YY\",
    \"More\",
    \"Multi-site Multi-lingual\",
    \"Name\",
    \"Only up to {version} is compatible with your version of Craft.\",
    \"Package Name\",
    \"Page not found.\",
    \"Pay\",
    \"Payment Method\",
    \"Payment\",
    \"Plugin Name\",
    \"Plugin Store\",
    \"Popularity\",
    \"Price includes 1 year of updates.\",
    \"Pro Rate Discount\",
    \"Reactivate\",
    \"Remove\",
    \"Renewal price\",
    \"Report an issue\",
    \"Save as my new credit card\",
    \"Screenshots\",
    \"Search plugins\",
    \"Security & Bug Fixes\",
    \"See all\",
    \"Showing results for “{searchQuery}”\",
    \"Staff Picks\",
    \"Subtotal\",
    \"Support\",
    \"System Branding\",
    \"Thank You!\",
    \"The Plugin Store is not available, please try again later.\",
    \"This plugin isn’t compatible with your version of Craft.\",
    \"Total Price\",
    \"Total\",
    \"Try for free\",
    \"Try\",
    \"Try\",
    \"Updates until {date} ({sign}{price})\",
    \"Updates until {date}\",
    \"Updates\",
    \"Upgrade Craft CMS\",
    \"Use a new credit card\",
    \"Use card {cardDetails}\",
    \"Use your Craft ID\",
    \"User Accounts\",
    \"Version {version}\",
    \"Version\",
    \"Website\",
    \"Your order has been processed successfully.\",
    \"Zip Code\",
    \"{price} plus {renewalPrice}/year for updates\",
    \"{price}/year\",
    \"{renewalPrice}/year per site for updates after that.\",
    \"Your are currently using the {currentEdition} edition, and your licensed edition is {licensedEdition}.\",
    \"This license is tied to another Craft install. Purchase a license for this install.\",
    \"Your license key is invalid.\",
    \"Critical\",
    \"Couldn’t add all items to the cart.\",
    \"No results.\",
]) %}

{% block actionButton %}
    <div id=\"pluginstore-actions-spinner\" class=\"spinner lg hidden\"></div>

    <div id=\"pluginstore-actions\" class=\"hidden\">

        <a id=\"cart-button\" role=\"button\" tabindex=\"0\">{{ svg('@app/icons/shopping-cart.svg', namespace=true) }} <span class=\"badge\">0</span></a>

        <a id=\"craftid-account\" class=\"menubtn hidden\"><span class=\"photo\">{{ svg('@app/icons/craftid.svg', namespace=true) }}</span><span class=\"label\">Account</span></a>

        <div class=\"menu\">
            <ul>
                <li><a href=\"{{ craft.cp.craftIdAccountUrl() }}\" rel=\"noopener\" target=\"_blank\">{{ \"Manage your Craft ID\"|t('app') }}</a></li>
                <li>
                    <form method=\"post\" id=\"disconnect\">
                        {{ csrfInput() }}
                        {{ actionInput('plugin-store/disconnect') }}
                        <a onclick=\"document.getElementById('disconnect').submit();\">{{ \"Sign out from Craft ID\"|t('app') }}</a>
                    </form>
                </li>
            </ul>
        </div>

        <form id=\"craftid-connect-form\" method=\"post\">
            {{ csrfInput() }}
            {{ actionInput('plugin-store/connect') }}
            <div class=\"ssl-status light\" title=\"{{ craft.app.request.isSecureConnection ? \"Your connection is secure\"|t('app') : \"Your connection is insecure\"|t('app') }}\">
                <i class=\"{{ craft.app.request.isSecureConnection ? \"secure\" : \"insecure\" }} icon\"></i>
            </div>
            <a onclick=\"document.getElementById('craftid-connect-form').submit();\">{{ 'Sign into Craft ID'|t('app') }}</a>
        </form>
    </div>
{% endblock %}

{% set content %}
    <div id=\"app\"></div>
{% endset %}
", "plugin-store/_index", "C:\\laragon\\www\\fakhri-craft\\vendor\\craftcms\\cms\\src\\templates\\plugin-store\\_index.html");
    }
}
