<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _include/footer.twig */
class __TwigTemplate_44703637bf5c9a1eef8e5c7a30a2d7813aa619217167c44a0c72b08fa614db75 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_include/footer.twig");
        // line 1
        echo "<footer class=\"p-2 absolute w-full text-center bg-gray-900 text-white\">
  <h3>Template By Fakhri Alauddin</h3>
</footer>";
        // line 0
        craft\helpers\Template::endProfile("template", "_include/footer.twig");
    }

    public function getTemplateName()
    {
        return "_include/footer.twig";
    }

    public function getDebugInfo()
    {
        return array (  42 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<footer class=\"p-2 absolute w-full text-center bg-gray-900 text-white\">
  <h3>Template By Fakhri Alauddin</h3>
</footer>", "_include/footer.twig", "C:\\laragon\\www\\fakhri-craft\\templates\\_include\\footer.twig");
    }
}
