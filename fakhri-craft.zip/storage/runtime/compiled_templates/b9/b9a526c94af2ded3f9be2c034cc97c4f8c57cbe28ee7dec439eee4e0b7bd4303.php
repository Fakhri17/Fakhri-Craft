<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _include/blog_list.twig */
class __TwigTemplate_20f02a0c8513a8d3ab37b83ee4de718896ecd6724660670b93b5b4884b48d40d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_include/blog_list.twig");
        // line 1
        echo "<div class=\"sm:w-1/3  sm:max-w-lg sm:rounded sm:overflow-hidden shadow-lg m-8 border border-black\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
  <div class=\"text-gray-700  p-4 \" >
    <div class=\"w-full mx-auto\">
      <a href=\"";
        // line 4
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 4, $this->source); })()), "url", []), "html", null, true);
        echo "\">
        <img class=\"h-40 mx-auto\"src=\"";
        // line 5
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 5, $this->source); })()), "html", null, true);
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 5, $this->source); })()), "image", []), "one", [], "method"), "url", []), "html", null, true);
        echo "\" alt=\"\">
      </a>
    </div>
    <div class=\"px-4 py-4\">
      <a href=\"";
        // line 9
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 9, $this->source); })()), "url", []), "html", null, true);
        echo "\">    
        <div class=\"font-bold text-xl mb-2\"> ";
        // line 10
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 10, $this->source); })()), "title", []), "html", null, true);
        echo "</div>
      </a>
      <div class=\" border border-blue-500 hover:bg-blue-500 sm:w-24  mx-auto m-5 px-1\">
        <p class=\"\">";
        // line 13
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 13, $this->source); })()), "kategori", []), "one", [], "method"), "html", null, true);
        echo "</p>
      </div>
    </div>
  </div>
</div>";
        // line 0
        craft\helpers\Template::endProfile("template", "_include/blog_list.twig");
    }

    public function getTemplateName()
    {
        return "_include/blog_list.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 0,  65 => 13,  59 => 10,  55 => 9,  47 => 5,  43 => 4,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"sm:w-1/3  sm:max-w-lg sm:rounded sm:overflow-hidden shadow-lg m-8 border border-black\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
  <div class=\"text-gray-700  p-4 \" >
    <div class=\"w-full mx-auto\">
      <a href=\"{{item.url}}\">
        <img class=\"h-40 mx-auto\"src=\"{{siteUrl}}{{item.image.one().url}}\" alt=\"\">
      </a>
    </div>
    <div class=\"px-4 py-4\">
      <a href=\"{{item.url}}\">    
        <div class=\"font-bold text-xl mb-2\"> {{item.title}}</div>
      </a>
      <div class=\" border border-blue-500 hover:bg-blue-500 sm:w-24  mx-auto m-5 px-1\">
        <p class=\"\">{{item.kategori.one()}}</p>
      </div>
    </div>
  </div>
</div>", "_include/blog_list.twig", "C:\\laragon\\www\\fakhri-craft\\templates\\_include\\blog_list.twig");
    }
}
