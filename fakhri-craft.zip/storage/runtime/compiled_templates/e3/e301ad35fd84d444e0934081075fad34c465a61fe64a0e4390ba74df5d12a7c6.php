<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/base.twig */
class __TwigTemplate_4b58fb074bf7bd78091c48b9cadf726953ba91d005370c906f4bf0c69b3e5fe6 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/base.twig");
        // line 1
        echo "<!DOCTYPE html>
<html>
  <head>
      <meta charset=\"UTF-8\">
      <meta name=\"description\" content=\"Free Web tutorials\">
      <meta name=\"keywords\" content=\"HTML,CSS,XML,JavaScript\">
      <meta name=\"author\" content=\"John Doe\">
      <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
      <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 9, $this->source); })()), "html", null, true);
        echo "assets/css/style.css\">
      <link href=\"https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css\" rel=\"stylesheet\">
      <link href=\"https://fonts.googleapis.com/css?family=Bowlby+One+SC\" rel=\"stylesheet\">
      <link href=\"https://unpkg.com/aos@2.3.1/dist/aos.css\" rel=\"stylesheet\">
      <title> FakhTech </title>
  ";
        // line 14
        call_user_func_array($this->env->getFunction('head')->getCallable(), []);
        echo "</head>
  <body>";
        // line 15
        call_user_func_array($this->env->getFunction('beginBody')->getCallable(), []);
        echo "
    ";
        // line 17
        echo "    ";
        $this->loadTemplate("_include/header.twig", "_layouts/base.twig", 17)->display($context);
        // line 18
        echo "    ";
        // line 19
        echo "    ";
        $this->displayBlock('content', $context, $blocks);
        // line 22
        echo "    ";
        $this->loadTemplate("_include/footer.twig", "_layouts/base.twig", 22)->display($context);
        // line 23
        echo "      <script src=\"";
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 23, $this->source); })()), "html", null, true);
        echo "assets/js/script.js\"></script>
      <script src=\"https://unpkg.com/aos@2.3.1/dist/aos.js\"></script>
      <script>
      AOS.init();
      </script>
  ";
        // line 28
        call_user_func_array($this->env->getFunction('endBody')->getCallable(), []);
        echo "</body>
</html>";
        // line 0
        craft\helpers\Template::endProfile("template", "_layouts/base.twig");
    }

    // line 19
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 20
        echo "        ";
        // line 21
        echo "    ";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "_layouts/base.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 0,  101 => 21,  99 => 20,  97 => 0,  93 => 19,  89 => 0,  85 => 28,  76 => 23,  73 => 22,  70 => 19,  68 => 18,  65 => 17,  61 => 15,  57 => 14,  49 => 9,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
  <head>
      <meta charset=\"UTF-8\">
      <meta name=\"description\" content=\"Free Web tutorials\">
      <meta name=\"keywords\" content=\"HTML,CSS,XML,JavaScript\">
      <meta name=\"author\" content=\"John Doe\">
      <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
      <link rel=\"stylesheet\" href=\"{{siteUrl}}assets/css/style.css\">
      <link href=\"https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css\" rel=\"stylesheet\">
      <link href=\"https://fonts.googleapis.com/css?family=Bowlby+One+SC\" rel=\"stylesheet\">
      <link href=\"https://unpkg.com/aos@2.3.1/dist/aos.css\" rel=\"stylesheet\">
      <title> FakhTech </title>
  </head>
  <body>
    {# Navbar #}
    {% include \"_include/header.twig\" %}
    {# end #}
    {% block content %}
        {# content #}
    {% endblock %}
    {% include \"_include/footer.twig\" %}
      <script src=\"{{siteUrl}}assets/js/script.js\"></script>
      <script src=\"https://unpkg.com/aos@2.3.1/dist/aos.js\"></script>
      <script>
      AOS.init();
      </script>
  </body>
</html>", "_layouts/base.twig", "C:\\laragon\\www\\fakhri-craft\\templates\\_layouts\\base.twig");
    }
}
