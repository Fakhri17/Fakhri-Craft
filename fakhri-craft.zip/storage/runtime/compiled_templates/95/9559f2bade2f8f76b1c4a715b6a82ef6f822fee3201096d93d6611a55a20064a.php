<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* patrol */
class __TwigTemplate_16e4923b5e8523cb37661d57772ea1317366045cc79dda234d3bfdc01710de52 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "patrol");
        // line 1
        \Craft::$app->getResponse()->redirect(craft\helpers\UrlHelper::url(craft\helpers\UrlHelper::cpUrl("settings/plugins/patrol")), 302);
        \Craft::$app->end();        // line 0
        craft\helpers\Template::endProfile("template", "patrol");
    }

    public function getTemplateName()
    {
        return "patrol";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% redirect cpUrl('settings/plugins/patrol') %}
", "patrol", "C:\\laragon\\www\\fakhri-craft\\vendor\\selvinortiz\\patrol\\src\\templates\\index.html");
    }
}
